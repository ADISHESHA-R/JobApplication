
import React from 'react';
import { JobPost } from '../types';
import { PencilIcon, TrashIcon } from './icons';

interface JobCardProps {
  job: JobPost;
  onEdit: () => void;
  onDelete: () => void;
}

const JobCard: React.FC<JobCardProps> = ({ job, onEdit, onDelete }) => {
  return (
    <div className="bg-slate-800 rounded-xl shadow-lg p-6 flex flex-col justify-between transition-all duration-300 hover:shadow-indigo-500/20 hover:scale-105 border border-slate-700">
      <div>
        <h3 className="text-xl font-bold text-indigo-300">{job.postProfile}</h3>
        <p className="text-slate-400 mt-2 text-sm">{job.reqExperience} years of experience required</p>
        <p className="text-slate-300 mt-4 h-24 overflow-hidden text-ellipsis">{job.postDesc}</p>
      </div>
      
      <div className="mt-4">
        <h4 className="text-sm font-semibold text-slate-400 mb-2">Tech Stack</h4>
        <div className="flex flex-wrap gap-2">
          {job.postTechStack.map((tech, index) => (
            <span key={index} className="bg-slate-700 text-indigo-300 text-xs font-medium px-2.5 py-1 rounded-full">
              {tech}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-6 flex justify-end space-x-3">
        <button onClick={onEdit} className="p-2 rounded-full text-slate-400 hover:bg-slate-700 hover:text-white transition-colors">
          <PencilIcon className="h-5 w-5" />
        </button>
        <button onClick={onDelete} className="p-2 rounded-full text-slate-400 hover:bg-slate-700 hover:text-red-400 transition-colors">
          <TrashIcon className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default JobCard;

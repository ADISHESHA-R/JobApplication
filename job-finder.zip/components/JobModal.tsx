
import React, { useState, useEffect } from 'react';
import { JobPost } from '../types';

interface JobModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (job: Omit<JobPost, 'postId'> | JobPost) => void;
    job: JobPost | null;
}

const JobModal: React.FC<JobModalProps> = ({ isOpen, onClose, onSave, job }) => {
    const [formData, setFormData] = useState({
        postProfile: '',
        postDesc: '',
        reqExperience: 0,
        postTechStack: '' 
    });

    useEffect(() => {
        if (job) {
            setFormData({
                postProfile: job.postProfile,
                postDesc: job.postDesc,
                reqExperience: job.reqExperience,
                postTechStack: job.postTechStack.join(', ')
            });
        } else {
            setFormData({
                postProfile: '',
                postDesc: '',
                reqExperience: 0,
                postTechStack: ''
            });
        }
    }, [job, isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: name === 'reqExperience' ? parseInt(value, 10) || 0 : value
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const techStackArray = formData.postTechStack.split(',').map(s => s.trim()).filter(s => s);
        
        const jobData = {
            ...formData,
            postTechStack: techStackArray,
        };

        if (job) {
            onSave({ ...jobData, postId: job.postId });
        } else {
            onSave(jobData);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl border border-slate-700 animate-fade-in-up">
                <div className="p-6 border-b border-slate-700 flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-white">{job ? 'Edit Job Post' : 'Add New Job Post'}</h2>
                    <button onClick={onClose} className="text-slate-400 hover:text-white">&times;</button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                    <div>
                        <label htmlFor="postProfile" className="block text-sm font-medium text-slate-300 mb-1">Job Title</label>
                        <input type="text" name="postProfile" id="postProfile" value={formData.postProfile} onChange={handleChange} className="w-full bg-slate-700 text-white rounded-lg border border-slate-600 focus:ring-2 focus:ring-indigo-500 focus:outline-none p-2.5 transition" required />
                    </div>
                    <div>
                        <label htmlFor="reqExperience" className="block text-sm font-medium text-slate-300 mb-1">Required Experience (years)</label>
                        <input type="number" name="reqExperience" id="reqExperience" value={formData.reqExperience} onChange={handleChange} className="w-full bg-slate-700 text-white rounded-lg border border-slate-600 focus:ring-2 focus:ring-indigo-500 focus:outline-none p-2.5 transition" required min="0"/>
                    </div>
                    <div>
                        <label htmlFor="postDesc" className="block text-sm font-medium text-slate-300 mb-1">Job Description</label>
                        <textarea name="postDesc" id="postDesc" value={formData.postDesc} onChange={handleChange} rows={5} className="w-full bg-slate-700 text-white rounded-lg border border-slate-600 focus:ring-2 focus:ring-indigo-500 focus:outline-none p-2.5 transition" required></textarea>
                    </div>
                    <div>
                        <label htmlFor="postTechStack" className="block text-sm font-medium text-slate-300 mb-1">Tech Stack (comma-separated)</label>
                        <input type="text" name="postTechStack" id="postTechStack" value={formData.postTechStack} onChange={handleChange} placeholder="e.g., Java, Spring, React, SQL" className="w-full bg-slate-700 text-white rounded-lg border border-slate-600 focus:ring-2 focus:ring-indigo-500 focus:outline-none p-2.5 transition" required/>
                    </div>
                    <div className="flex justify-end pt-4 space-x-4">
                        <button type="button" onClick={onClose} className="py-2 px-4 bg-slate-600 hover:bg-slate-500 text-white font-semibold rounded-lg transition">Cancel</button>
                        <button type="submit" className="py-2 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg transition">Save</button>
                    </div>
                </form>
            </div>
             <style>{`
                @keyframes fade-in-up {
                    0% {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    100% {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                .animate-fade-in-up {
                    animation: fade-in-up 0.3s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default JobModal;

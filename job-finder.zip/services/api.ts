
import { API_BASE_URL } from '../constants';
import { JobPost } from '../types';

async function handleResponse<T,>(response: Response): Promise<T> {
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`API Error: ${response.status} ${response.statusText} - ${errorText}`);
    }
    // Handle cases where response might be just text (like "Deleted Successfully")
    const contentType = response.headers.get("content-type");
    if (contentType && contentType.indexOf("application/json") !== -1) {
        return response.json();
    }
    return response.text() as unknown as T;
}

export const getAllJobs = async (): Promise<JobPost[]> => {
    const response = await fetch(`${API_BASE_URL}/jobPosts`);
    return handleResponse<JobPost[]>(response);
};

export const searchJobs = async (keyword: string): Promise<JobPost[]> => {
    const response = await fetch(`${API_BASE_URL}/jobPost/keyword/${keyword}`);
    return handleResponse<JobPost[]>(response);
};

export const addJob = async (jobData: Omit<JobPost, 'postId'>): Promise<JobPost> => {
    const response = await fetch(`${API_BASE_URL}/jobPost`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(jobData),
    });
    return handleResponse<JobPost>(response);
};

export const updateJob = async (jobData: JobPost): Promise<JobPost> => {
    const response = await fetch(`${API_BASE_URL}/jobPost`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(jobData),
    });
    return handleResponse<JobPost>(response);
};

export const deleteJob = async (postId: number): Promise<string> => {
    const response = await fetch(`${API_BASE_URL}/jobPosts/${postId}`, {
        method: 'DELETE',
    });
    return handleResponse<string>(response);
};

export const loadData = async (): Promise<string> => {
    const response = await fetch(`${API_BASE_URL}/load`);
    return handleResponse<string>(response);
};

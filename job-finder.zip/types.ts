
export interface JobPost {
  postId: number;
  postProfile: string;
  postDesc: string;
  reqExperience: number;
  postTechStack: string[];
}

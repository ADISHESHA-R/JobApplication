
import React, { useState, useEffect, useCallback } from 'react';
import { JobPost } from './types';
import * as api from './services/api';
import JobModal from './components/JobModal';
import JobCard from './components/JobCard';
import Spinner from './components/Spinner';
import { BriefcaseIcon, PlusIcon, SearchIcon, RefreshIcon } from './components/icons';

const App: React.FC = () => {
    const [jobs, setJobs] = useState<JobPost[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState<string>('');

    const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
    const [editingJob, setEditingJob] = useState<JobPost | null>(null);

    const fetchJobs = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const data = searchTerm ? await api.searchJobs(searchTerm) : await api.getAllJobs();
            setJobs(data);
        } catch (err) {
            setError('Failed to fetch jobs. Please make sure the backend server is running.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [searchTerm]);

    useEffect(() => {
        fetchJobs();
    }, [fetchJobs]);

    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(e.target.value);
    };

    const handleSearchSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        fetchJobs();
    };
    
    const handleOpenModal = (job: JobPost | null) => {
        setEditingJob(job);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingJob(null);
    };

    const handleSaveJob = async (job: Omit<JobPost, 'postId'> | JobPost) => {
        try {
            if ('postId' in job && job.postId) {
                await api.updateJob(job);
            } else {
                await api.addJob(job);
            }
            handleCloseModal();
            fetchJobs(); // Refresh job list
        } catch (err) {
            setError('Failed to save job post.');
            console.error(err);
        }
    };

    const handleDeleteJob = async (postId: number) => {
        if (window.confirm('Are you sure you want to delete this job post?')) {
            try {
                await api.deleteJob(postId);
                fetchJobs(); // Refresh job list
            } catch (err) {
                setError('Failed to delete job post.');
                console.error(err);
            }
        }
    };

    const handleLoadData = async () => {
        if (window.confirm('This will load sample data. Are you sure?')) {
            try {
                await api.loadData();
                alert('Sample data loaded successfully!');
                fetchJobs();
            } catch (err) {
                setError('Failed to load sample data.');
                console.error(err);
            }
        }
    };


    return (
        <div className="min-h-screen bg-slate-900 text-gray-100 font-sans">
            <header className="bg-slate-800/50 backdrop-blur-lg sticky top-0 z-10 p-4 border-b border-slate-700">
                <div className="container mx-auto flex justify-between items-center">
                    <div className="flex items-center space-x-3">
                        <BriefcaseIcon className="h-8 w-8 text-indigo-400" />
                        <h1 className="text-2xl font-bold tracking-tight text-white">Job Finder</h1>
                    </div>
                    <div className="flex items-center space-x-2">
                        <button
                            onClick={handleLoadData}
                            className="flex items-center bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 transform hover:scale-105"
                        >
                            <RefreshIcon className="h-5 w-5 mr-2" />
                            Load Data
                        </button>
                        <button
                            onClick={() => handleOpenModal(null)}
                            className="flex items-center bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 transform hover:scale-105"
                        >
                            <PlusIcon className="h-5 w-5 mr-2" />
                            Add Job
                        </button>
                    </div>
                </div>
            </header>
            
            <main className="container mx-auto p-4 md:p-8">
                <div className="mb-8 p-6 bg-slate-800 rounded-xl shadow-lg">
                    <h2 className="text-2xl font-bold mb-4 text-indigo-300">Find Your Next Opportunity</h2>
                    <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-4">
                        <div className="relative flex-grow">
                             <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400"/>
                            <input
                                type="text"
                                value={searchTerm}
                                onChange={handleSearchChange}
                                placeholder="Search by keyword (e.g., 'React', 'Java', 'Spring')..."
                                className="w-full pl-12 pr-4 py-3 bg-slate-700 text-white rounded-lg border border-slate-600 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
                            />
                        </div>
                        <button
                            type="submit"
                            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300 flex items-center justify-center"
                        >
                            Search
                        </button>
                    </form>
                </div>

                {isLoading ? (
                    <div className="flex justify-center items-center h-64">
                        <Spinner />
                    </div>
                ) : error ? (
                    <div className="text-center p-8 bg-red-900/50 border border-red-700 rounded-lg">
                        <p className="text-red-300 text-xl">{error}</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {jobs.length > 0 ? (
                            jobs.map(job => (
                                <JobCard 
                                    key={job.postId} 
                                    job={job} 
                                    onEdit={() => handleOpenModal(job)} 
                                    onDelete={() => handleDeleteJob(job.postId)} 
                                />
                            ))
                        ) : (
                            <div className="col-span-full text-center py-16">
                                <p className="text-slate-400 text-xl">No job posts found.</p>
                                {searchTerm && <p className="text-slate-500 mt-2">Try a different keyword or clear the search.</p>}
                            </div>
                        )}
                    </div>
                )}
            </main>
            
            <JobModal
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                onSave={handleSaveJob}
                job={editingJob}
            />
        </div>
    );
};

export default App;
